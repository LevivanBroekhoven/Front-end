fetch("opdracht2_bijlage.json")
  .then(response => response.json())
  .then(jsonData => {
    console.log(jsonData);
    
    var Displayjson = document.createElement("div");

    jsonData.forEach(person => {
      Displayjson.appendChild(document.createTextNode("Voornaam: " + person.voornaam));
      Displayjson.appendChild(document.createElement("br"));

      Displayjson.appendChild(document.createTextNode("Achternaam: " + person.achternaam));
      Displayjson.appendChild(document.createElement("br"));

      Displayjson.appendChild(document.createTextNode("Nationaliteit: " + person.nationaliteit));
      Displayjson.appendChild(document.createElement("br")); 

      Displayjson.appendChild(document.createTextNode("Leeftijd: " + person.leeftijd));
      Displayjson.appendChild(document.createElement("br"));

      Displayjson.appendChild(document.createTextNode("Gewicht: " + person.gewicht));
      Displayjson.appendChild(document.createElement("br"));

      Displayjson.appendChild(document.createElement("br"));
    });

    var page = document.getElementById("container");
    page.appendChild(Displayjson);
  });





