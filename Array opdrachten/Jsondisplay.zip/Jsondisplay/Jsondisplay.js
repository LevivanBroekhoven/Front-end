fetch("opdracht1_bijlage.json")
  .then(response => response.json())
  .then(jsonData => {
    console.log(jsonData);
    
    var Displayjson = document.createElement("div");

    Displayjson.appendChild(document.createTextNode("Voornaam: " + jsonData.voornaam));
    Displayjson.appendChild(document.createElement("br"));

    Displayjson.appendChild(document.createTextNode("Achternaam: " + jsonData.achternaam));
    Displayjson.appendChild(document.createElement("br"));

    Displayjson.appendChild(document.createTextNode("Nationaliteit: " + jsonData.nationaliteit));
    Displayjson.appendChild(document.createElement("br"));

    Displayjson.appendChild(document.createTextNode("Leeftijd: " + jsonData.leeftijd));
    Displayjson.appendChild(document.createElement("br"));

    Displayjson.appendChild(document.createTextNode("Gewicht: " + jsonData.gewicht));
    Displayjson.appendChild(document.createElement("br"));

    var page = document.getElementById("container");
    page.appendChild(Displayjson);
  });





